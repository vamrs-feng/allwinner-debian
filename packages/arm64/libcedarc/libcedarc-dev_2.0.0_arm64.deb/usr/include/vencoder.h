/*
* Copyright (c) 2008-2016 Allwinner Technology Co. Ltd.
* All rights reserved.
*
* File : vencoder.h
* Description :
* History :
*   Author  : fangning <fangning@allwinnertech.com>
*   Date    : 2016/04/13
*   Comment :
*
*
*/

/*
 *this software is based in part on the work
 * of the Independent JPEG Group
 */
#include "sc_interface.h"
#include "veInterface.h"

//*v1 and v2: please check the comment in base/include/CdcPlatformConfig.h
#include "vencoder_platform_v1.h"
#include "vencoder_platform_v2.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#ifndef _VENCODER_H_
#define _VENCODER_H_

#define  DATA_TIME_LENGTH           24
#define  INFO_LENGTH                64
#define  GPS_PROCESS_METHOD_LENGTH  100
#define  DESCRIPTOR_INFO            128
#define  PROC_BUF_LEN               1024
#define  MAX_CHANNEL_NUM            16

#define MAX_FRM_NUM                       5
#define MAX_GOP_SIZE                      63
#define MAX_OVERLAY_SIZE                  64

#define VENCODER_TMP_RATIO (14)

#define VENC_BUFFERFLAG_KEYFRAME 0x00000001
#define VENC_BUFFERFLAG_EOS 0x00000002
#define VENC_BUFFERFLAG_THUMB 0x00000004

#define DEFAULT_REGION_E3D_HOR_REGION_NUM    (30)
#define DEFAULT_REGION_E3D_VER_REGION_NUM    (17)
#define DEFAULT_REGION_E3D_RESULT_NUM        (2)

#define H264_VERSION2_USE64 0

#define CLASSIFY_TH_NUM (16)

typedef struct VencQPRange {
    int    nMaxqp;
    int    nMinqp;

	//*just support VE_ENCODER_VERSION_2, please check the comment in base/include/CdcPlatformConfig.h
    int    nMaxPqp;
    int    nMinPqp;
    int    nQpInit;
    int    bEnMbQpLimit;
	//*end
}VencQPRange;

typedef struct {
    unsigned int            uMaxBitRate;
    unsigned int            nMovingTh;      //range[1,31], 1:all frames are moving,
                                            //            31:have no moving frame, default: 20
    int                     nQuality;       //range[1,20], 1:worst quality, 20:best quality

	//*just support VE_ENCODER_VERSION_2, please check the comment in base/include/CdcPlatformConfig.h
    int                     nIFrmBitsCoef;   //range[1, 20], 1:worst quality, 20:best quality
    int                     nPFrmBitsCoef;   //range[1, 50], 1:worst quality, 50:best quality
	//*end
}VencVbrParam;

typedef struct {
    unsigned char mode_ctrl_en;
    unsigned char *p_info;

    //*just support VE_ENCODER_VERSION_2, please check the comment in base/include/CdcPlatformConfig.h
    unsigned int  last_slice_type;
    unsigned int  est_bit_rate;
    unsigned int  pre_est_bits;
    unsigned int  cur_est_bits;
    unsigned int  frm_mad;
    unsigned int  frm_mse;
    int           mad_mb_num;
    int           mse_mb_num;
    int           force_qp_num;
    int           en_chn_mse_qp;
    float         mad_qp_ratio;
    float         mse_qp_ratio;
    float         force_qp_ratio;
    sQpMapPara    qp_map_para;
    sCtuQpInfo    *p_ctu_info;
    //*end
}VencMBModeCtrl;

typedef enum {
    PSKIP               = 0,
    BSKIP_DIRECT        = 0,
    P16x16              = 1,
    P16x8               = 2,
    P8x16               = 3,
    SMB8x8              = 4,
    SMB8x4              = 5,
    SMB4x8              = 6,
    SMB4x4              = 7,
    P8x8                = 8,
    I4MB                = 9,
    I16MB               = 10,
    IBLOCK              = 11,
    SI4MB               = 12,
    I8MB                = 13,
    IPCM                = 14,
    MAXMODE             = 15
}MB_TYPE;

typedef struct {
    short         mv_x;
    short         mv_y;
    int           mode;
    unsigned char lt_flag;
    unsigned short depth;
} VencMotionVector;

#ifdef CONF_VE_ENCODER_VERSION_1
typedef struct {
    MB_TYPE mb_type;
    VencMotionVector mb_mv;
}MbMvList;
#endif

typedef struct rational_t {
    unsigned int num;
    unsigned int den;
}rational_t;

typedef struct srational_t {
    int num;
    int den;
}srational_t;

typedef enum ExifMeteringModeType {
    UNKNOWN_AW_EXIF,
    AVERAGE_AW_EXIF,
    CENTER_AW_EXIF,
    SPOT_AW_EXIF,
    MULTISPOT_AW_EXIF,
    PATTERN_AW_EXIF,
    PARTIAL_AW_EXIF,
    OTHER_AW_EXIF     = 255,
} ExifMeteringModeType;

typedef enum ExifExposureModeType {
    EXPOSURE_AUTO_AW_EXIF,
    EXPOSURE_MANUAL_AW_EXIF,
    EXPOSURE_AUTO_BRACKET_AW_EXIF,
}ExifExposureModeType;

typedef enum {
    UNKNOWN = 0,
    SUNLIGHT = 1,
    TUNGSTEN_LAMP = 2,
    FILAMENT_LAMP = 3,
    FLASH_LAMP = 4,
    OVERCAST = 9,
    CLOUDY = 10,
    SHADOW = 11,
    INCANDESCENT_LAMP = 12,
    WHITE_DAY_FLUORESCENT_LAMP = 13,
    COOL_COLOUR_FLUORESCENT_LAMP = 14,
    WHITE_FLUORESCENT_LAMP = 15,
    STANDARD_LAMP_A = 17,
    STANDARD_LAMP_B = 18,
    STANDARD_lAMP_C = 19,
    D55 = 20,
    D65 = 21,
    D75 = 22,
    D50= 23,
    PROJECTION_ROOM_LAMP = 24,
    OTHERS = 255
}ExifLightSource;

typedef struct EXIFInfo {
    unsigned char  CameraMake[INFO_LENGTH];
    unsigned char  CameraModel[INFO_LENGTH];
    unsigned char  DateTime[DATA_TIME_LENGTH];

    unsigned int   ThumbWidth;
    unsigned int   ThumbHeight;
    unsigned char* ThumbAddrVir;
    unsigned int   ThumbLen;

    int              Orientation;  //value can be 0,90,180,270 degree
    rational_t       ExposureTime; //tag 0x829A
    rational_t       FNumber; //tag 0x829D
    short           ISOSpeed;//tag 0x8827

    srational_t    ShutterSpeedValue; //tag 0x9201
    rational_t       Aperture; //tag 0x9202
    //srational_t    BrightnessValue;   //tag 0x9203
    srational_t    ExposureBiasValue; //tag 0x9204

    rational_t       MaxAperture; //tag 0x9205

    short           MeteringMode; //tag 0x9207
    short           LightSource; //tag 0x9208
    short           FlashUsed;     //tag 0x9209
    rational_t       FocalLength; //tag 0x920A

    rational_t       DigitalZoomRatio; // tag 0xA404
    short           WhiteBalance; //tag 0xA403
    short           ExposureMode; //tag 0xA402

    unsigned char   subSecTime[8];
    unsigned char   subSecTimeOrig[8];
    unsigned char   subSecTimeDig[8];

    // gps info
    int            enableGpsInfo;
    double         gps_latitude;
    double           gps_longitude;
    double         gps_altitude;
    long           gps_timestamp;
    unsigned char  gpsProcessingMethod[GPS_PROCESS_METHOD_LENGTH];

    unsigned char  CameraSerialNum[128];     //tag 0xA431 (exif 2.3 version)
    short              FocalLengthIn35mmFilm;     // tag 0xA405

    unsigned char  ImageName[128];             //tag 0x010D
    unsigned char  ImageDescription[128];     //tag 0x010E
    short            ImageWidth;                 //tag 0xA002
    short            ImageHeight;             //tag 0xA003

    int             thumb_quality;
}EXIFInfo;

typedef struct VencRect {
    int nLeft;
    int nTop;
    int nWidth;
    int nHeight;
}VencRect;

typedef struct VencCropCfg {
	int      bEnable;
	VencRect Rect;
} VencCropCfg;

typedef struct VencHwCrop {
    unsigned int   bEnCrop;
    unsigned int   bVirZoom;
    VencRect CropRect;
    unsigned int ori_out_width;
    unsigned int ori_out_height;
} VencHwCrop;

typedef struct VencE3DParam{
	int e3d_en;
	int dis_default_para;
	int pix_diff_en;
	int pix_diff_th[3];      // range[0, 31]
	int delta_pix_coef[4];   // range[-4, 3]
	int motion_avg_th;       // range[0, 63]
	int motion_mv_th;        // range[0, 63]
	int min_coef;            // range[0, 15]
	int max_coef;            // range[0, 15]
} VencE3DParam;

typedef struct {
    int pix_x_bgn;
    int pix_x_end;
    int pix_y_bgn;
    int pix_y_end;
    int total_num;
    int zero_mv_num;
    int is_possible_static;
    int is_really_static;
    float zero_mv_rate;
} VencRegionE3DRegion;

typedef struct sVencRegionE3DResult VencRegionE3DResult;
struct sVencRegionE3DResult {
    int total_region_num;
    int static_region_num;
    VencRegionE3DRegion *region;
    VencRegionE3DResult **prev;
    VencRegionE3DResult **next;
};

typedef struct {
    int en_region_d3d;
    int dis_default_para;
    int result_num;
    int hor_region_num;
    int ver_region_num;
    int hor_expand_num;
    int ver_expand_num;
    int lv_weak_th[9];
    float zero_mv_rate_th[3];
    unsigned char static_coef[3]; //* fallow by zero_mv_rate
    unsigned char motion_coef[4]; //* fallow by MoveStatus
} VencRegionE3DParam;

typedef enum {
    CAMERA_ADAPTIVE_STATIC = 0,
    CAMERA_FORCE_STATIC = 1,
    CAMERA_FORCE_MOVING = 2,
    CAMERA_ADAPTIVE_MOVING_AND_STATIC = 3,
    CAMERA_STATUS_NUM
} eCameraStatus;

typedef enum VENC_YUV2YUV {
    VENC_YCCToBT601,
    VENC_BT601ToYCC,
}VENC_YUV2YUV;

typedef enum VENC_CODING_MODE {
  VENC_FRAME_CODING         = 0,
  VENC_FIELD_CODING         = 1,
}VENC_CODING_MODE;

//* The Amount of Temporal SVC Layers
typedef enum {
    NO_T_SVC = 0,
    T_LAYER_2 = 2,
    T_LAYER_3 = 3,
    T_LAYER_4 = 4
}T_LAYER;

//* The Multiple of Skip_Frame
typedef enum {
    NO_SKIP = 0,
    SKIP_2 = 2,
    SKIP_4 = 4,
    SKIP_8 = 8
}SKIP_FRAME;

typedef enum VENC_CODEC_TYPE {
    VENC_CODEC_H264,
    VENC_CODEC_JPEG,
    VENC_CODEC_H264_VER2,
    VENC_CODEC_H265,
    VENC_CODEC_VP8,
}VENC_CODEC_TYPE;

typedef enum VENC_PIXEL_FMT {
    VENC_PIXEL_YUV420SP,
    VENC_PIXEL_YVU420SP,
    VENC_PIXEL_YUV420P,
    VENC_PIXEL_YVU420P,
    VENC_PIXEL_YUV422_BEGIN,
    VENC_PIXEL_YUV422SP,
    VENC_PIXEL_YVU422SP,
    VENC_PIXEL_YUV422P,
    VENC_PIXEL_YVU422P,
    VENC_PIXEL_YUYV422,
    VENC_PIXEL_UYVY422,
    VENC_PIXEL_YVYU422,
    VENC_PIXEL_VYUY422,
    VENC_PIXEL_YUV422_END,
    VENC_PIXEL_ARGB,
    VENC_PIXEL_RGBA,
    VENC_PIXEL_ABGR,
    VENC_PIXEL_BGRA,
    VENC_PIXEL_TILE_32X32,
    VENC_PIXEL_TILE_128X32,
    VENC_PIXEL_AFBC_AW,
    VENC_PIXEL_LBC_AW, //* for v5v200 and newer ic
}VENC_PIXEL_FMT;

typedef enum E_ISP_SCALER_RATIO {
    VENC_ISP_SCALER_0       = 0, //no write back
    VENC_ISP_SCALER_EIGHTH  = 1, //scaler 1/8 write back
    VENC_ISP_SCALER_HALF    = 2, //scaler 1/2 write back
    VENC_ISP_SCALER_QUARTER = 3, //scaler 1/4 write back
}E_ISP_SCALER_RATIO;

typedef struct ThumbWbYuvInfo {
    unsigned int b_wb_yuv;
    E_ISP_SCALER_RATIO eIspScalerRatio;
} ThumbWbYuvInfo;

typedef struct VencThumbInfo {
    unsigned int        nThumbSize;
    unsigned char*      pThumbBuf;
}VencThumbInfo;

typedef struct VencBaseConfig {
    unsigned char       bEncH264Nalu;
    unsigned int        nInputWidth;
    unsigned int        nInputHeight;
    unsigned int        nDstWidth;
    unsigned int        nDstHeight;
    unsigned int        nStride;
    VENC_PIXEL_FMT      eInputFormat;
    struct ScMemOpsS *memops;
    VeOpsS*           veOpsS;
    void*             pVeOpsSelf;

    unsigned char     bOnlyWbFlag;

    //* for v5v200 and newer ic
    unsigned char     bLbcLossyComEnFlag2x;
    unsigned char     bLbcLossyComEnFlag2_5x;
    unsigned char     bIsVbvNoCache;
	//* end

	//* for MR536
    unsigned int bVcuAutoMode;
    unsigned int nFrameNumInGroup;
    unsigned int extend_flag;
    unsigned int en_vcu;
	//* end
}VencBaseConfig;

/**
 * H264 profile types
 */
typedef enum VENC_H264PROFILETYPE {
    VENC_H264ProfileBaseline  = 66,         /**< Baseline profile */
    VENC_H264ProfileMain      = 77,         /**< Main profile */
    VENC_H264ProfileHigh      = 100,           /**< High profile */
}VENC_H264PROFILETYPE;

/**
 * H264 level types
 */
typedef enum VENC_H264LEVELTYPE {
    VENC_H264Level1   = 10,     /**< Level 1 */
    VENC_H264Level11  = 11,     /**< Level 1.1 */
    VENC_H264Level12  = 12,     /**< Level 1.2 */
    VENC_H264Level13  = 13,     /**< Level 1.3 */
    VENC_H264Level2   = 20,     /**< Level 2 */
    VENC_H264Level21  = 21,     /**< Level 2.1 */
    VENC_H264Level22  = 22,     /**< Level 2.2 */
    VENC_H264Level3   = 30,     /**< Level 3 */
    VENC_H264Level31  = 31,     /**< Level 3.1 */
    VENC_H264Level32  = 32,     /**< Level 3.2 */
    VENC_H264Level4   = 40,     /**< Level 4 */
    VENC_H264Level41  = 41,     /**< Level 4.1 */
    VENC_H264Level42  = 42,     /**< Level 4.2 */
    VENC_H264Level5   = 50,     /**< Level 5 */
    VENC_H264Level51  = 51,     /**< Level 5.1 */
    VENC_H264Level52  = 52,     /**< Level 5.2 */
    VENC_H264LevelDefault = 0
}VENC_H264LEVELTYPE;

typedef struct VencH264ProfileLevel {
    VENC_H264PROFILETYPE    nProfile;
    VENC_H264LEVELTYPE        nLevel;
}VencH264ProfileLevel;

typedef struct MotionParam {
    int nMotionDetectEnable;
    int nMotionDetectRatio; /* 0~12, advise set 0 */
    int nStaticDetectRatio; /* 0~12, should be larger than  nMotionDetectRatio, advise set 2 */
    int nMaxNumStaticFrame; /* advise set 4 */
    double nStaticBitsRatio; /* advise set 0.2~0.3 at daytime, set 0.1 at night */
    double nMV64x64Ratio; /* advise set 0.01 */
    short nMVXTh; /* advise set 6 */
    short nMVYTh; /* advise set 6 */
}MotionParam;

typedef struct VencHeaderData {
    unsigned char*  pBuffer;
    unsigned int    nLength;
}VencHeaderData;

/* support 4 ROI region */
typedef struct VencROIConfig {
    int                     bEnable;
    int                        index; /* (0~3) */
    int                     nQPoffset;
    unsigned char           roi_abs_flag;
    VencRect                sRect;
}VencROIConfig;

typedef struct VencFixQP {
    int                     bEnable;
    int                     nIQp;
    int                     nPQp;
}VencFixQP;

typedef struct VencCopyROIConfig {
    int                     bEnable;
    int                     num; /* (0~16) */
    VencRect                sRect[16];
    unsigned char         *pRoiYAddrVir;
    unsigned char         *pRoiCAddrVir;
    unsigned long         pRoiYAddrPhy;
    unsigned long         pRoiCAddrPhy;
}VencCopyROIConfig;


typedef enum {
    AW_CBR = 0,
    AW_VBR = 1,
    AW_AVBR = 2,
    AW_QPMAP = 3,
    AW_FIXQP = 4,
}VENC_RC_MODE;

typedef struct VencInputBuffer {
    unsigned long  nID;
    long long         nPts;
    unsigned int   nFlag;
    unsigned char* pAddrPhyY;
    unsigned char* pAddrPhyC;
    unsigned char* pAddrVirY;
    unsigned char* pAddrVirC;
    int            nWidth;
    int            nHeight;
    int            nAlign;
    int            bEnableCorp;
    VencRect       sCropInfo;

    int            ispPicVar;
    int            ispPicVarChroma;     //chroma  filter  coef[0-63],  from isp
    int			   bUseInputBufferRoi;
    VencROIConfig  roi_param[8];
    int            bAllocMemSelf;
    int            nShareBufFd;
    unsigned char  bUseCsiColorFormat;
    VENC_PIXEL_FMT eCsiColorFormat;

    int             envLV;
}VencInputBuffer;

typedef struct FrameInfo {
    int             CurrQp;
    int             avQp;
    int             nGopIndex;
    int             nFrameIndex;
    int             nTotalIndex;
    unsigned int    sliceType;
}FrameInfo;

typedef struct VeProcSet {
    unsigned char               bProcEnable;
    unsigned int                nProcFreq;
	unsigned int				nStatisBitRateTime;
	unsigned int				nStatisFrRateTime;
}VeProcSet;

#define MAX_OUTPUT_PACK_NUM (8)

typedef enum {
	 VENC_H264_NALU_PSLICE = 1, 						/*PSLICE types*/
	 VENC_H264_NALU_ISLICE = 5, 						/*ISLICE types*/
	 VENC_H264_NALU_SEI    = 6, 						/*SEI types*/
	 VENC_H264_NALU_SPS    = 7, 						/*SPS types*/
	 VENC_H264_NALU_PPS    = 8, 						/*PPS types*/
	 VENC_H264_NALU_IPSLICE = 9,
	 VENC_H264_NALU_SVC    = 14,						/*SVC Prefix types*/
} VENC_H264_NALU_TYPE;

typedef enum {
	 VENC_H265_NALU_PSLICE = 1, 						/*P SLICE types*/
	 VENC_H265_NALU_ISLICE = 19,						/*I SLICE types*/
	 VENC_H265_NALU_VPS    = 32,						/*VPS types*/
	 VENC_H265_NALU_SPS    = 33,						/*SPS types*/
	 VENC_H265_NALU_PPS    = 34,						/*PPS types*/
	 VENC_H265_NALU_SEI    = 39,						/*SEI types*/
} VENC_H265_NALU_TYPE;

typedef enum {
	 VENC_JPEG_PACK_ECS = 5,							/*ECS types*/
	 VENC_JPEG_PACK_APP = 6,							/*APP types*/
	 VENC_JPEG_PACK_VDO = 7,							/*VDO types*/
	 VENC_JPEG_PACK_PIC = 8,							/*PIC types*/
} VENC_JPEGE_PACK_TYPE;

typedef union {
	VENC_H264_NALU_TYPE    eH264Type;				/*H264E NALU types*/
	VENC_JPEGE_PACK_TYPE   eJpegType;				/*JPEGE pack types*/
	VENC_H265_NALU_TYPE    eH265Type;				/*H264E NALU types*/
} VENC_OUTPUT_PACK_TYPE;

typedef struct {
	VENC_OUTPUT_PACK_TYPE  uType;
	unsigned int		   nOffset;
	unsigned int		   nLength;
} VencPackInfo;

typedef struct VencOutputBuffer {
    int               nID;
    long long         nPts;
    unsigned int   nFlag;
    unsigned int   nSize0;
    unsigned int   nSize1;
    unsigned char* pData0;
    unsigned char* pData1;

    FrameInfo       frame_info;
    unsigned int   nSize2;
    unsigned char* pData2;

	unsigned int   nExSize0;
	unsigned int   nExSize1;
	unsigned char  *pExData0;
	unsigned char  *pExData1;

	unsigned int   nPackNum;
	VencPackInfo   mPackInfo[MAX_OUTPUT_PACK_NUM];
}VencOutputBuffer;

typedef struct VencAllocateBufferParam {
    unsigned int   nBufferNum;
    unsigned int   nSizeY;
    unsigned int   nSizeC;
}VencAllocateBufferParam;

#define EXTENDED_SAR 255
typedef struct VencH264AspectRatio {
    unsigned char aspect_ratio_idc;
    unsigned short  sar_width;
    unsigned short  sar_height;
}VencH264AspectRatio;

typedef struct {
    unsigned int frame_cropping_flag;
    unsigned int frame_crop_left_offset;
    unsigned int frame_crop_right_offset;
    unsigned int frame_crop_top_offset;
    unsigned int frame_crop_bottom_offset;
} VencH264SpecCropInfo;

typedef struct VencSaveBSFile {
    char filename[256];
    unsigned char save_bsfile_flag;
    unsigned char force_save_bsfile_flag;
    unsigned int save_start_time;
    unsigned int save_end_time;
}VencSaveBSFile;

typedef enum VENC_COLOR_SPACE {
    RESERVED0           = 0,
    VENC_BT709          = 1,  // include BT709-5, BT1361, IEC61966-2-1 IEC61966-2-4
    RESERVED1           = 2,
    RESERVED2           = 3,
    VENC_BT470          = 4,  // include BT470-6_SystemM,
    VENC_BT601          = 5,  // include BT470-6_SystemB, BT601-6_625, BT1358_625, BT1700_625
    VENC_SMPTE_170M     = 6,  // include SMPTE_170M, BT601-6_525, BT1358_525, BT1700_NTSC
    VENC_SMPTE_240M     = 7,  // include SMPTE_240M
    VENC_YCC            = 8,  // include GENERIC_FILM
    VENC_BT2020         = 9,  // include BT2020
    VENC_ST_428         = 10, // include SMPTE_428-1
	VENC_BT601_525      = 11, // bt601-525
}VENC_COLOR_SPACE;

typedef enum VENC_VIDEO_FORMAT {
    COMPONENT       = 0,                 /* component */
    PAL             = 1,                 /* pal*/
    NTSC            = 2,                 /* ntsc */
    SECAM           = 3,                /* secam  */
    MAC             = 4,                /* mac  */
    DEFAULT         = 5,                /* Unspecified video format  */
}VENC_VIDEO_FORMAT;

typedef struct VencJpegVideoSignal {
    VENC_COLOR_SPACE src_colour_primaries;
    VENC_COLOR_SPACE dst_colour_primaries;
}VencJpegVideoSignal;

typedef struct VencH264VideoSignal {
    VENC_VIDEO_FORMAT video_format;

    unsigned char full_range_flag;
    unsigned char transfer_characteristics;
    unsigned char matrix_coefficients;

    VENC_COLOR_SPACE src_colour_primaries;
    VENC_COLOR_SPACE dst_colour_primaries;
}VencH264VideoSignal;

typedef struct VencH264VideoTiming {
      unsigned long num_units_in_tick;
      unsigned long time_scale;
      unsigned int fixed_frame_rate_flag;

}VencH264VideoTiming;

// Add for setting SVC and Skip_Frame
typedef struct VencH264SVCSkip {
    T_LAYER        nTemporalSVC;
    SKIP_FRAME     nSkipFrame;
    int            bEnableLayerRatio;
    unsigned int   nLayerRatio[4];
}VencH264SVCSkip;

typedef struct VencCyclicIntraRefresh {
    int                     bEnable;
    int                     nBlockNumber;
}VencCyclicIntraRefresh;

typedef struct VencSize {
    int                     nWidth;
    int                     nHeight;
}VencSize;

typedef enum VENC_VIDEO_GOP_MODE {
    AW_NORMALP         = 1,//one p ref frame
    AW_ADVANCE_SINGLE  = 2,
    AW_DOUBLEP         = 3,
    AW_SPECIAL_DOUBLE  = 4,
    AW_SPECIAL_SMARTP  = 5,//double p ref frames and use virtual i frame,but virtual i ref virtual i
    AW_SMARTP          = 6,//double p ref frames and use virtual i frame
}VENC_VIDEO_GOP_MODE;

typedef struct VencAdvancedRefParam {
    unsigned char              bAdvancedRefEn;   //advanced ref frame mode, 0:not use , 1:use
    unsigned int               nBase;       //base frame num
    unsigned int               nEnhance;    //enhance frame num
    unsigned char              bRefBaseEn;  //ctrl base frame ref base frame, 0:enable, 1:disable
}VencAdvancedRefParam;

typedef struct VencGopParam {
    unsigned char              bUseGopCtrlEn;   //use user set gop mode
    VENC_VIDEO_GOP_MODE        eGopMode;        //gop mode
    unsigned int               nVirtualIFrameInterval;
    unsigned int               nSpInterval;     //user set special p frame ref interval
    VencAdvancedRefParam       sRefParam;       //user set advanced ref frame mode
}VencGopParam;

typedef struct VencCheckColorFormat {
    int                        index;
    VENC_PIXEL_FMT          eColorFormat;
}VencCheckColorFormat;

typedef struct VencVP8Param {
    int                     nFramerate; /* fps*/
    int                     nBitrate;   /* bps*/
    int                     nMaxKeyInterval;
}VencVP8Param;

typedef enum VENC_SUPERFRAME_MODE {
    VENC_SUPERFRAME_NONE,
    VENC_SUPERFRAME_DISCARD,
    VENC_SUPERFRAME_REENCODE,
}VENC_SUPERFRAME_MODE;

typedef enum VENC_SUPERFRAME_PRIORITY {
	VENC_SUPERF_RPQ_BALANCE = 0,
	VENC_SUPERF_BIT_RATE_FIRST,
	VENC_SUPERF_FRAME_BITS_FIRST,
	VENC_SUPERFE_BUTT,
} VENC_SUPERFRAME_PRIORITY;

typedef struct VencSuperFrameConfig {
    VENC_SUPERFRAME_MODE    eSuperFrameMode;
    unsigned int            nMaxIFrameBits;
    unsigned int            nMaxPFrameBits;
	VENC_SUPERFRAME_PRIORITY eSuperPriority;
    int                     nMaxRencodeTimes;
    float                   nMaxP2IFrameBitsRatio;
} VencSuperFrameConfig;

typedef struct VencBitRateRange {
    int            bitRateMax;
    int            bitRateMin;
}VencBitRateRange;

typedef struct VencRoiBgFrameRate {
    int            nSrcFrameRate;
    int            nDstFrameRate;
}VencRoiBgFrameRate;

typedef struct VencAlterFrameRateInfo {
    unsigned char       bEnable;
    unsigned char       bUseUserSetRoiInfo;   //0:use csi roi info; 1:use user set roi info
    VencRoiBgFrameRate  sRoiBgFrameRate;
    VencROIConfig       roi_param[8];
}VencAlterFrameRateInfo;

typedef struct VencH265TranS {
    /*** unsigned char       transquant_bypass_enabled_flag; not support ***/
    //0:disable transform skip; 1:enable transform skip
    unsigned char       transform_skip_enabled_flag;
    //chroma_qp= sliece_qp+chroma_qp_offset
    int                chroma_qp_offset;
}VencH265TranS;

typedef struct VencH265SaoS {
    //0:disable luma sao filter; 1:enable luma sao filter
    unsigned char       slice_sao_luma_flag;
    //0:disable chroma sao filter; 1:enable chroma sao filter
    unsigned char       slice_sao_chroma_flag;
}VencH265SaoS;

typedef struct VencH265DblkS {
    //0:enable deblock filter; 1:disable deblock filter
    unsigned char       slice_deblocking_filter_disabled_flag;
    char                slice_beta_offset_div2; //range: [-6,6]
    char                slice_tc_offset_div2; //range: [-6,6]
}VencH265DblkS;

typedef struct VencH265TimingS {
    //0:stream without timing info; 1:stream with timing info
    unsigned char       timing_info_present_flag;
    unsigned int        num_units_in_tick;       //time_scale/frameRate
    unsigned int        time_scale;             //1second is  average divided by time_scale
    unsigned int        num_ticks_poc_diff_one; //num ticks of diff frame
}VencH265TimingS;

typedef enum VENC_OVERLAY_ARGB_TYPE {
    VENC_OVERLAY_ARGB_MIN    = -1,
    VENC_OVERLAY_ARGB8888    = 0,
    VENC_OVERLAY_ARGB4444   = 1,
    VENC_OVERLAY_ARGB1555   = 2,
    VENC_OVERLAY_ARGB_MAX    = 3,
}VENC_OVERLAY_ARGB_TYPE;

typedef enum VENC_OVERLAY_TYPE {
    NORMAL_OVERLAY          = 0,    //normal overlay
    COVER_OVERLAY           = 1,    //use the setting yuv to cover region
    LUMA_REVERSE_OVERLAY    = 2,    //normal overlay and luma reverse
}VENC_OVERLAY_TYPE;

typedef struct VencOverlayCoverYuvS {
     //1:use the cover yuv; 0:transform the argb data to yuv ,then cover
     unsigned char       use_cover_yuv_flag;
     unsigned char       cover_y; //the value of cover y
     unsigned char       cover_u; //the value of cover u
     unsigned char       cover_v; //the value of cover v
}VencOverlayCoverYuvS;

typedef struct VencOverlayHeaderS {
    unsigned short      start_mb_x;         //horizonal value of  start points divided by 16
    unsigned short      end_mb_x;           //horizonal value of  end points divided by 16
    unsigned short      start_mb_y;         //vertical value of  start points divided by 16
    unsigned short      end_mb_y;           //vertical value of  end points divided by 16
    unsigned char       extra_alpha_flag;   //0:no use extra_alpha; 1:use extra_alpha
    unsigned char       extra_alpha;        //use user set extra_alpha, range is [0, 15]
    VencOverlayCoverYuvS cover_yuv;         //when use COVER_OVERLAY should set the cover yuv
    VENC_OVERLAY_TYPE   overlay_type;       //reference define of VENC_OVERLAY_TYPE
    unsigned char*      overlay_blk_addr;   //the vir addr of overlay block
    unsigned int        bitmap_size;        //the size of bitmap

    //* for v5v200 and newer ic
    unsigned int        bforce_reverse_flag;
    unsigned int        reverse_unit_mb_w_minus1;
    unsigned int        reverse_unit_mb_h_minus1;
    //* end

}VencOverlayHeaderS;

typedef struct VencOverlayInfoS {
    unsigned char               blk_num; //num of overlay region
    VENC_OVERLAY_ARGB_TYPE      argb_type;//reference define of VENC_ARGB_TYPE
    VencOverlayHeaderS          overlayHeaderList[MAX_OVERLAY_SIZE];

    //* for v5v200 and newer ic
    unsigned int                invert_mode;
    unsigned int                invert_threshold;
    //* end

}VencOverlayInfoS;

typedef struct VencBrightnessS {
    unsigned int               dark_th; //dark threshold, default 60, range[0, 255]
    unsigned int               bright_th; //bright threshold, default 200, range[0, 255]
}VencBrightnessS;

typedef struct VencEncodeTimeS {
    unsigned int                  frame_num; //current frame num
    unsigned int                  curr_enc_time; //current frame encoder time
    unsigned int                  curr_empty_time; //the time between current frame and last frame
    unsigned int                  avr_enc_time; //average encoder time
    unsigned int                  avr_empty_time; //average empty time
    unsigned int                  max_enc_time;
    unsigned int                  max_enc_time_frame_num;
    unsigned int                  max_empty_time;
    unsigned int                  max_empty_time_frame_num;
}VencEncodeTimeS;

typedef enum VENC_INDEXTYPE {
    VENC_IndexParamBitrate                = 0x0,
    /**< reference type: int */
    VENC_IndexParamFramerate,
    /**< reference type: int */
    VENC_IndexParamMaxKeyInterval,
    /**< reference type: int */
    VENC_IndexParamIfilter,
    /**< reference type: int */
    VENC_IndexParamRotation,
    /**< reference type: int */
    VENC_IndexParamSliceHeight,
    /**< reference type: int */
    VENC_IndexParamForceKeyFrame,
    /**< reference type: int (write only)*/
    VENC_IndexParamMotionDetectEnable,
    /**< reference type: MotionParam(write only) */
    VENC_IndexParamMotionDetectStatus,
    /**< reference type: int(read only) */
    VENC_IndexParamRgb2Yuv,
    /**< reference type: VENC_COLOR_SPACE */
    VENC_IndexParamYuv2Yuv,
    /**< reference type: VENC_YUV2YUV */
    VENC_IndexParamROIConfig,
    /**< reference type: VencROIConfig */
    VENC_IndexParamStride,
    /**< reference type: int */
    VENC_IndexParamColorFormat,
    /**< reference type: VENC_PIXEL_FMT */
    VENC_IndexParamSize,
    /**< reference type: VencSize(read only) */
    VENC_IndexParamSetVbvSize,
    /**< reference type: setVbvSize(write only) */
    VENC_IndexParamVbvInfo,
    /**< reference type: getVbvInfo(read only) */
    VENC_IndexParamSuperFrameConfig,
    /**< reference type: VencSuperFrameConfig */
    VENC_IndexParamSetPSkip,
    /**< reference type: unsigned int */
    VENC_IndexParamResetEnc,
    /**< reference type: */
	VENC_IndexParamSaveBSFile,
	/**< reference type: VencSaveBSFile */
	VENC_IndexParamHorizonFlip,
	/**< reference type: unsigned int */

    /* check capabiliy */
    VENC_IndexParamMAXSupportSize,
    /**< reference type: VencSize(read only) */
    VENC_IndexParamCheckColorFormat,
    /**< reference type: VencCheckFormat(read only) */

    /* H264 param */
    VENC_IndexParamH264Param  = 0x100,
    /**< reference type: VencH264Param */
    VENC_IndexParamH264SPSPPS,
    /**< reference type: VencHeaderData (read only)*/
    VENC_IndexParamH264QPRange,
    /**< reference type: VencQPRange */
    VENC_IndexParamH264ProfileLevel,
    /**< reference type: VencProfileLevel */
    VENC_IndexParamH264EntropyCodingCABAC,
    /**< reference type: int(0:CAVLC 1:CABAC) */
    VENC_IndexParamH264CyclicIntraRefresh,
    /**< reference type: VencCyclicIntraRefresh */
    VENC_IndexParamH264FixQP,
    /**< reference type: VencFixQP */
    VENC_IndexParamH264SVCSkip,
    /**< reference type: VencH264SVCSkip */
    VENC_IndexParamH264AspectRatio,
    /**< reference type: VencH264AspectRatio */
    VENC_IndexParamFastEnc,
    /**< reference type: int */
    VENC_IndexParamH264VideoSignal,
    /**< reference type: VencH264VideoSignal */
    VENC_IndexParamH264VideoTiming,
    /**< reference type: VencH264VideoTiming */
    VENC_IndexParamChmoraGray,
    /**< reference type: unsigned char */
    VENC_IndexParamIQpOffset,
    /**< reference type: constant QP */
    VENC_IndexParamH264ConstantQP,
    /**< reference type: int */
    /* jpeg param */
    VENC_IndexParamJpegQuality            = 0x200,
    /**< reference type: int (1~100) */
    VENC_IndexParamJpegExifInfo,
    /**< reference type: EXIFInfo */
    VENC_IndexParamJpegEncMode,
    /**< reference type: 0:jpeg; 1:motion_jepg */
    VENC_IndexParamJpegVideoSignal,
    /**< reference type: VencJpegVideoSignal */

    /* VP8 param */
    VENC_IndexParamVP8Param,
    /* max one frame length */
    VENC_IndexParamSetFrameLenThreshold,
    /**< reference type: int */
    /* decrease the a20 dram bands */
    VENC_IndexParamSetA20LowBands,
    /**< reference type: 0:disable; 1:enable */
    VENC_IndexParamSetBitRateRange,
    /**< reference type: VencBitRateRange */
    VENC_IndexParamLongTermReference,
    /**< reference type: 0:disable; 1:enable, default:enable */

    /* h265 param */
    VENC_IndexParamH265Param = 0x300,
    VENC_IndexParamH265Gop,
    VENC_IndexParamH265ToalFramesNum,
    VENC_IndexParamH26xUpdateLTRef,
    VENC_IndexParamH265Header,
    VENC_IndexParamH265TendRatioCoef,
	VENC_IndexParamH265Trans,
    /**< reference type: VencH265TranS */
    VENC_IndexParamH265Sao,
    /**< reference type: VencH265SaoS */
    VENC_IndexParamH265Dblk,
    /**< reference type: VencH265DblkS */
    VENC_IndexParamH265Timing,
    /**< reference type: VencH265TimingS */
    VENC_IndexParamIntraPeriod,
    VENC_IndexParamMBModeCtrl,
    VENC_IndexParamMBSumInfoOutput,
    /**< reference type: VencH265TimingS VencMBSumInfo*/
    VENC_IndexParamMBInfoOutput,
    VENC_IndexParamVUIAspectRatio,
    VENC_IndexParamVUIVideoSignal,
    VENC_IndexParamVUIChromaLoc,
    VENC_IndexParamVUIDisplayWindow,
    VENC_IndexParamVUIBitstreamRestriction,

    VENC_IndexParamAlterFrame = 0x400,
    /**< reference type: unsigned int */
    VENC_IndexParamVirtualIFrame,
    VENC_IndexParamChannelNum,
    VENC_IndexParamProcSet,
    /**< reference type: VencOverlayInfoS */
    VENC_IndexParamSetOverlay,
    /**< reference type: unsigned char */
    VENC_IndexParamAllParams,
    /**< reference type:VencBrightnessS */
    VENC_IndexParamBright,
    /**< reference type:VencSmartFun */
    VENC_IndexParamSmartFuntion,
    /**< reference type: VencHVS */
    VENC_IndexParamHVS,
    /**< reference type: unsigned char */
    VENC_IndexParamSkipTend,
    /**< reference type: unsigned char */
    VENC_IndexParamHighPassFilter,
    /**< reference type: unsigned char */
    VENC_IndexParamPFrameIntraEn,
    /**< reference type: unsigned char */
    VENC_IndexParamEncodeTimeEn,
    /**< reference type: VencEncodeTimeS */
    VENC_IndexParamGetEncodeTime,
    /**< reference type: VencE3DParam */
    VENC_IndexParam3DFilter,
    /**< reference type: Set or Get VencRegionE3DParam* */
    VENC_IndexParamRegionE3DParam,
    /**< reference type: Get VencRegionE3DResult* */
    VENC_IndexParamRegionE3DResult,
    /**< reference type: unsigned char */
    VENC_IndexParamIntra4x4En,

    /**< reference type: unsigned int */
    VENC_IndexParamSetNullFrame = 0x500,
    /**< reference type: VencThumbInfo */
    VENC_IndexParamGetThumbYUV,
    /**< reference type: E_ISP_SCALER_RATIO */
    VENC_IndexParamSetThumbScaler,
    /**< reference type: unsigned char */
    VENC_IndexParamAdaptiveIntraInP,
    /**< reference type: VencBaseConfig */
    VENC_IndexParamUpdateBaseInfo,

    /**< reference type: unsigned char */
    VENC_IndexParamFillingCbr,

    /**< reference type: unsigned char */
    VENC_IndexParamRoi,

    /**< reference type: unsigned int */
    /* drop the frame that bitstreamLen exceed vbv-valid-size */
    VENC_IndexParamDropOverflowFrame,

    /**< reference type: unsigned int; 0: day, 1: night*/
    VENC_IndexParamIsNightCaseFlag,

    /**< reference type: VencProductModeInfo */
    VENC_IndexParamProductCase,
    VENC_IndexParamSpecCropInfo,

    /**< reference type:  VencH264ConstraintFlag */
    VENC_IndexParamH264ConstraintFlag,

	/**< reference type: VencForceConfWin */
	VENC_IndexParamForceConfWin,

	/**< reference type: VencSeiParam */
	VENC_IndexParamSeiParam,

    /**< reference type: eCameraStatus */
    VENC_IndexParamEnCameraMove,

    /**< reference type: VencTargetBitsClipParam */
    VENC_IndexParamTargetBitsClipParam,

    /**< reference type: sIspMotionParam */
    VENC_IndexParamIspMotionParam,

	/**< reference type: VencVe2IspParam */
	VENC_IndexParamVe2IspParam,

    /**< reference type: int [0,1]*/
    VENC_IndexParamVbrOptEnable,

    /**< reference type: VencVbrOptParam*/
    VENC_IndexParamVbrOptParam,

	/**< reference type: int [1,51] */
    VENC_IndexParamLensMovingMaxQp,

	/**< reference type: sRegionLinkParam*/
    VENC_IndexParamRegionDetectLinkParam,

	/**< reference type: VencIspVeLinkParam*/
	VENC_IndexParamIspVeLinkParam,
}VENC_INDEXTYPE;


typedef enum VENC_RESULT_TYPE {
    VENC_RESULT_ERROR             = -1,
    VENC_RESULT_OK                   = 0,
    VENC_RESULT_NO_FRAME_BUFFER   = 1,
    VENC_RESULT_BITSTREAM_IS_FULL = 2,
    VENC_RESULT_ILLEGAL_PARAM     = 3,
    VENC_RESULT_NOT_SUPPORT     = 4,
    VENC_RESULT_BITSTREAM_IS_EMPTY = 5,
    VENC_RESULT_NO_MEMORY     = 6,
    VENC_RESULT_NO_RESOURCE     = 7,
    VENC_RESULT_NULL_PTR     = 8,
    VENC_RESULT_DROP_FRAME   = 9,

    VENC_RESULT_EFUSE_ERROR  = 25,
}VENC_RESULT_TYPE;

typedef enum {
    PICTURE_SLICE_INVALID       = 0x0,
    PICTURE_B_SLICE             = 1<<0,
    PICTURE_P_SLICE             = 1<<1,
    PICTURE_I_SLICE             = 1<<2,
    PICTURE_IDR_SLICE           = 1<<3,
}VENC_PICTURE_SLICE_TYPE;

typedef enum {
    H265_B_SLICE             = 0x0,
    H265_P_SLICE             = 0x1,
    H265_I_SLICE             = 0x2,
    H265_IDR_SLICE           = 0x12
}VENC_H265_CODE_TYPE;

typedef struct JpegEncInfo {
    VencBaseConfig  sBaseInfo;
    int             bNoUseAddrPhy;
    unsigned char*  pAddrPhyY;
    unsigned char*  pAddrPhyC;
    unsigned char*  pAddrVirY;
    unsigned char*  pAddrVirC;
    int             bEnableCorp;
    VencRect        sCropInfo;
    int                quality;
    int             nShareBufFd;
}JpegEncInfo;

typedef struct VbvInfo {
    unsigned int vbv_size;
    unsigned int coded_frame_num;
    unsigned int coded_size;
    unsigned int maxFrameLen;
}VbvInfo;

typedef enum {
    PRODUCT_STATIC_IPC = 0,
    PRODUCT_MOVING_IPC = 1,
    PRODUCT_DOORBELL = 2,
    PRODUCT_CDR = 3,
    PRODUCT_SDV = 4,
    PRODUCT_PROJECTION = 5,
    PRODUCT_UAV = 6,       // Unmanned Aerial Vehicle
    PRODUCT_NUM,
} eVencProductMode;

typedef struct {
	eVencProductMode eProductMode;
	unsigned int     nDstWidth;
	unsigned int     nDstHeight;
	int              nBitrate;   // bps
	int              nFrameRate;
} VencProductModeInfo;

#define FACTOR_MAX_NUM 8

typedef enum {
	VENC_RC_RPQ_BALANCE_Q = 0,       // balance bit rate and quality, slightly more focused on quality, default value
	VENC_RC_RPQ_BALANCE_R,           // balance bit rate and quality, slightly more focused on bit rate
	VENC_RC_AVERAGE_BIT_RATE_FIRST,  // Average bitrate is guaranteed first
	VENC_RC_RT_BIT_RATE_FIRST,       // Instantaneous bitrate is guaranteed first
	VENC_RC_BUTT,
} VENC_RC_PRIORITY;

typedef enum {
	VENC_QUALITY_LOW_LEVEL = 0,     // use with VENC_RC_PRIORITY, low peak bitrate and quality, suitable for low bit rate application, default value
	VENC_QUALITY_MIDDLE_LEVEL,      // use with VENC_RC_PRIORITY, middle peak bitrate and quality
	VENC_QUALITY_HIGH_LEVEL,        // use with VENC_RC_PRIORITY, high peak bitrate and quality
	VENC_QUALITY_LEVEL_NUM,
} VENC_QUALITY_LEVEL;

typedef struct {
	unsigned char closeMbRcEn;       // range[0, 1], when closeMbRcEn = 1, the best quality, default value 1
	unsigned char MoveStatusTh;      // range[0, 4], motion status threshold, use default
	unsigned int  MbQpTightLimitEn;  // range[0, 1], enable macroblock qp narrowing adjustment amplitude, when MbQpTightLimitEn = 1, the best quality, default value 1
	int 		  uAddDeltaQp;       // range[0, 10], limit classify adjustment qp amplitude, the large the value, the best the image quality, use default
	unsigned int  uSliceQpMaxTh;     // range[minqp, maxqp], the smaller the value, the best the image quality, use default
} InsideClipQpFunc;

typedef struct {
	int 		  nFactorLevelNum;                  // range[1, 8], the number of adjustment intervals, use default
	float		  ExceedTarBrRatio;                 // range[0.1f, 3.0f], exceed max target bitrate*ExceedTarBrRatio need to save bits, use default
	float		  SmallTarBrRatio;                  // range[0.1f, 3.0f], increase bits if the intantenus bitrate is less than target bitrate*smallTarBrRatio, use default
	float		  recodeExceedTarBrRatio;           // range[0.1f, 3.0f], the smaller the value, the best the image quality, use default
	float		  fgAdjustFactorTh[FACTOR_MAX_NUM]; // range[0.01f, 3.0f], InstaneousBitRate exceed ratio, use default
	float		  fgAdjustFactor[FACTOR_MAX_NUM];   // range[0.01f, 1.0f], target bit adjust ratio, use default
	unsigned char  clpParamMode;                    // range[0, 2], 0: use soft param calc, 1: use hard param calc, 2: close func, default value 0
	unsigned short clpStep;                         // range[4, 512], adjust sharp white and black clp, use default, vaild when clpParamMode = 1
	unsigned short clplimitLowTh;                   // range[1, 1023]
	float          clpRtlimitFactor[2];             // range[0.1, 5], vaild when clpParamMode = 0
} InsideInstaneousBitRatePar;

typedef struct {
	unsigned int         uVbrOptEn;                 // range[0, 1], follow the vbr(New) enable, internal automatic setting, use default
	unsigned int         uPrintVbrTraceInfoEn;      // range[0, 1], print vbr trace info enable, default value 0, use default
	unsigned int         uPrintLogInfoEn;           // range[0, 1], print vbr log enable, default value 0, use default
	int                  PrintRegInfoFrameNum;      // range[0~], print register value of a certain frame, use default
	int                  nIFrameRcInfoNum;          // range[1, 16], number of saved I-frame historical vbr info, use default
	int                  nPFrameRcInfoNum;          // range[1, 16], number of saved P-frame historical vbr info, use default
	int                  nSaveBitQpTh;              // range[minqp, maxqp], no more need to save bit allocation threshold, use default
	int                  nBoostBitQpTh;             // range[minqp, maxqp], no longer increase bit number allocation, use defalut
	int                  nBppLevelNum;              // range[1, 8], total number of bpp level, use default
	int                  nIPSliceQpMaxGap;          // range[1, 15], maximun interval of P-I frame sliceQp, the large the value, the worse the image quality stability
	int                  nMvStaLevelNum;            // range[1, 7], number of integer pixel mv statistical intervals, use default
	int                  nStaMvTh[FACTOR_MAX_NUM];  // range[1, 128], thresholds for each interval of integer pixel mv, use default
	int                  nAvgMvFactor;              // range[1,2^N], N<=10, mv mean precision, use default
	int                  nAvgQpRatio;               // range[0, 16], avgqp mean weight coefficient, use default
	int                  nDeltaQp;                  // range[0, 10], the large the value, the worse the image quality stability, use default
	int                  nMaxHistoryFrameNum[2];    // range[1, maxKeyI - 1], use default
	float                fInitAvgMovingLevel;       // range[0.0f, 0.5f], initial move level, the larger the value, the stronger the move, use defalut
	float                fAvgMoveLevelRatio;        // range[0.0f, 1.0f], AvgMoveLevel mean weight coefficient, use default
	float                fMinRatio[2];              // range[0.0f, 3.0f], fMinRatio[0]:use for I slice,fMinRatio[1]:use for P slice, use default
	float                fMaxRatio[2];              // range[0.0f, 3.0f], fMaxRatio[0]:use for I slice,fMaxRatio[1]:use for P slice, use default
	float                fMinRaioTh[2];             // range[0.0f, 3.0f], fMinRaioTh[0]:use for I slice,fMinRaioTh[1]:use for P slice, use default
	float                fMaxRatioTh[2];            // range[0.0f, 3.0f], fMaxRatioTh[0]:use for I slice,fMaxRatioTh[1]:use for P slice, use default
	float                fBppLevel[2][FACTOR_MAX_NUM];       // range[0.0f, 256.0f], bpp level threshold, use default
	float                fAdjustQpBppTh[2][FACTOR_MAX_NUM];  // range[0.0f, 1.0f], bpp threshold used for adjust sliceqp, use default
	float                fAdjustMaxQp[2][FACTOR_MAX_NUM];    // range[0.0f, 7.0f], adjust maximun of delta qp based on bpp level, use default
	float                fMoveFrameLevelTh;                  // range[0.0f, 0.5f], large motion scene threshold, use default
	float                fStaticFrameLevelTh;                // range[0.0f, 0.5f], static scene threshold, use default
	float                fluctuationFactorTh;                // range[1, 30], the large the value, the worse the image quality stability, default value 10
	unsigned char        uIframeMadThOpt[12];                // range[0, 255], adjust qp based on mad (I slice), ternal automatic setting, use default
	unsigned char        uPframeMadThOpt[12];                // range[0, 255], adjust qp based on mad (P slice), ternal automatic setting, use default
} InsideVbrKeyPar;

typedef struct {
	//mosaic opt param
	unsigned int         uConstantLargeMoveNumTh;   // range[2, maxKeyI - 1], continuous motion frame number threshold, use default
	unsigned int         uConstantStaticNumTh;      // range[1, maxKeyI - 1], continuous static frame number threshold, use default
	unsigned int         uMethodSelect;             // range[0, 3], default value 1
													// 0:constand move frame adjust sliceqp;
													// 1:constand move frame and MoveToStatic frame adjust slice qp
													// 2:adjust target bits
													// 3:no opeartion
	unsigned int         uAdjustSliceQpPeriod;      // range[1, maxKeyI - 1], slice Qp adjust period, use default
	unsigned int         uSliceQpLimitTh;           // range[minqp, maxqp], adjusrt sliceQp upper limit threshold, use default
	int                  nMosAicSliceDeltaQp;       // range[-10, 10], sliceQp adjustment range, the smaller the value, the bset the image quality, default value -6
	float                nScaleDeltaRatio;          // range[0.0f, 3.0f], scale ratio for bit, use default
} InsideVbrMosAicOptPar;

typedef struct {
	unsigned int         uConstandMoveToStaticNumTh;                // range[1, maxKeyI - 1], not use
	int                  nMoveToStaticSliceQpDelta[FACTOR_MAX_NUM]; // range[-10,10], adjustment range of sliceQp from different motion level to static scene, use default
																	// the smaller the value, the bset the image quality
	int                  nMoveToStaticDelayNum[4];                  // range[0, maxKeyI - 1], adjust the sliceQp period frame number for different motion level to statis scene, use default
	float                fFrameMvLevelTh[FACTOR_MAX_NUM];           // range[0.0f, 1.0f], motion level judgment threshold, use default
} InsideVbrMoveToStaticPar;

typedef struct {
	unsigned char breathEn;        // range[0,1], 0: close breath effect optimize, 1:open (default)
	unsigned char updateParamMode; // range[0,1], 0: sliceQp update is last I, 1:sliceQp update is avg(default)
	unsigned int  uIFrameSizeTh;   // range[5,bitrate*framerate/8*0.7], unit byte,need bitrate and framerate calc, use default
	int           sliceIIQpGap;    // range[0,5], the smaller the value, the best the image quality, instantaneous rate control will be incearse
	int           sliceIPQpGap;    // range[0,10], the smaller the value, the best the image quality, instantaneous rate control will be incearse
	int           rtBitrateFactor; // range[0,200], the larger the value, the best the image quality, instantaneous rate control will be incearse
} InsideBreathFunc;

typedef struct {
	InsideVbrKeyPar            vbrKeyPar;
	InsideVbrMosAicOptPar      vbrMosAicOptPar;
	InsideVbrMoveToStaticPar   vbrMoveToStaticPar;
	InsideInstaneousBitRatePar vbrInstaneousBRPar;
	InsideClipQpFunc           mclipQpOpt;
	InsideBreathFunc           mBreathOpt;
} InsideVbrOptPar;

typedef struct {
	int                  nIPratio;               // range[10, 100], the larger the value of nIPratio, the larger the size of IDR, use default
	int                  nIntraPeriodNumInVbv;   // range[1, 10], use default
	unsigned char        enable_instaneousBR;    // range[0, 1], Instantaneous rate control strategy enabled
	unsigned int         max_instaneousBR;       // range[104857, 104857600], unit bps
	unsigned int         peroid_instaneousBR;    // range[20, 120], as an integer multiple of tha frame rate, use default
	unsigned char        recodeIsliceQpEn;       // range[0, 1], modify I slice Qp enable
	unsigned int         uMosAicOptEn;           // range[0, 1], mosaic opt enable
	unsigned int         uSaveBitRateEn;         // range[0, 1], save bit rate enable
	unsigned int         uClassifyMadThAdjustEn; // range[0, 1], modify mad threshold enable, use default
	unsigned int         uMoveToStaticOptEn;     // range[0, 1], motion to still video quality improve enable
	InsideVbrOptPar      pVbrOptPar;
	VENC_RC_PRIORITY     sRcPriority;            // range[0, 3], rate control priority
	VENC_QUALITY_LEVEL   eQualityLevel;          // range[0, 2], quality level, the larger the value, the best the image quality
} VencVbrOptParam;

typedef struct {
	int dis_default_para;
	int mode;
	int en_gop_clip;
	float gop_bit_ratio_th[3];
	float coef_th[5][2];
} VencTargetBitsClipParam;

typedef struct {
	int en_d2d_limit;
	int d2d_level[6];
} VencVe2IspD2DLimit;

typedef struct {
	int dis_default_d2d;
	int d2d_min_lv_th;
	int d2d_max_lv_th;
	int d2d_min_lv_level;
	int d2d_max_lv_level;
	int dis_default_d3d;
	int d3d_min_lv_th;
	int d3d_max_lv_th;
	int d3d_min_lv_level;
	int d3d_max_lv_level;
} VencRotVe2Isp;

typedef struct {
	int dis_default_para;
	int large_mv_th;
} VencIspMotionParam;

#define ISP_TABLE_LEN (22)

typedef struct {
	unsigned char is_overflow;
	unsigned short moving_level_table[ISP_TABLE_LEN * ISP_TABLE_LEN];
} MovingLevelInfo;

typedef struct {
	int d2d_level; //[1,1024], 256 means 1X
	int d3d_level; //[1,1024], 256 means 1X
	MovingLevelInfo mMovingLevelInfo;
} VencVe2IspParam;

typedef struct {
	unsigned char isp2VeEn;
	unsigned char ve2IspEn;
} VencIspVeLinkParam;

typedef enum {
    VENC_H265ProfileMain        = 1,
    VENC_H265ProfileMain10      = 2,
    VENC_H265ProfileMainStill   = 3
}VENC_H265PROFILETYPE;

typedef enum {
    VENC_H265Level1   = 30,     /**< Level 1 */
    VENC_H265Level2   = 60,     /**< Level 2 */
    VENC_H265Level21  = 63,     /**< Level 2.1 */
    VENC_H265Level3   = 90,     /**< Level 3 */
    VENC_H265Level31  = 93,     /**< Level 3.1 */
    VENC_H265Level4   = 120,      /**< Level 4 */
    VENC_H265Level41  = 123,     /**< Level 4.1 */
    VENC_H265Level5   = 150,     /**< Level 5 */
    VENC_H265Level51  = 153,     /**< Level 5.1 */
    VENC_H265Level52  = 156,     /**< Level 5.2 */
    VENC_H265Level6   = 180,     /**< Level 6 */
    VENC_H265Level61  = 183,     /**< Level 6.1 */
    VENC_H265Level62  = 186,     /**< Level 6.2 */
    VENC_H265LevelDefault = 0
}VENC_H265LEVELTYPE;

typedef enum {
    REF_IDC_DISCARD = 0,
    REF_IDC_CURRENT_USE = 1,
    REF_IDC_FUTURE_USE = 2,
    REF_IDC_LONG_TERM = 4,
    REF_IDC_CURRENT_REF = 8,
}ReferenceIdc;

typedef struct {
    VENC_H265PROFILETYPE    nProfile;
    VENC_H265LEVELTYPE        nLevel;
}VencH265ProfileLevel;

typedef struct {
    VENC_RC_MODE            eRcMode;
    unsigned char           bLowBitrateBeginFlag;
    unsigned char           bUseSetMadThrdFlag;
    unsigned char           uMadThrdI[CLASSIFY_TH_NUM]; //range 0-255
    unsigned char           uMadThrdP[CLASSIFY_TH_NUM]; //range 0-255
    unsigned char           uMadThrdB[CLASSIFY_TH_NUM]; //no support
    unsigned char           uMadQpI[CLASSIFY_TH_NUM];
	unsigned char           uMadQpP[CLASSIFY_TH_NUM];
    unsigned int            uStatTime;      //range [1,10], default:1
    unsigned int            uMinIQp;
    int                     nMaxReEncodeTimes; //default use one time

    VencVbrParam            sVbrParam;      //valid only at AW_VBR/AW_AVBR
    VencFixQP               sFixQp;         //valid only at AW_FIXQP
    VencMBModeCtrl          sQpMap;         //valid only at AW_QPMAP

    unsigned int            uRowQpDelta; //no support
    unsigned int            uDirectionThrd; //no support
    unsigned int            uQpDeltaLevelI; //no support
    unsigned int            uQpDeltaLevelP; //no support
    unsigned int            uQpDeltaLevelB; //no support
    unsigned int            uInputFrmRate;  //no support
    unsigned int            uOutputFrmRate; //no support
    unsigned int            uFluctuateLevel;//no support
    unsigned int            uMinIprop;      //no support
    unsigned int            uMaxIprop;      //no support
}VencRcParam;

typedef struct VencH264Param {
    VencH264ProfileLevel    sProfileLevel;
    int                     bEntropyCodingCABAC; /* 0:CAVLC 1:CABAC*/
    VencQPRange               sQPRange;
    int                     nFramerate; /* fps*/
    int                     nSrcFramerate; /* fps*/
    int                     nBitrate;   /* bps*/
    int                     nMaxKeyInterval;
    VENC_CODING_MODE        nCodingMode;
    VencGopParam            sGopParam;
    VencRcParam             sRcParam;
}VencH264Param;

typedef struct {
    int                     idr_period;
    VencH265ProfileLevel    sProfileLevel;
    VencQPRange               sQPRange;
    int                     nFramerate; /* fps*/
    int                     nSrcFramerate; /* fps*/
    int                     nBitrate;   /* bps*/
    int                     nIntraPeriod;
    int                     nGopSize;
    int                     nQPInit; /* qp of first IDR_frame if use rate control */
    VencRcParam             sRcParam;
    VencGopParam            sGopParam;
}VencH265Param;

typedef struct {
    unsigned int    slice_type;
    int             poc; // dispaly order of the frame within a GOP, ranging from 1 to gop_size
    int             qp_offset;
#if 0
    float           qp_factor; // used for RDO weighting,the bigger value means the lower quality
                                        // and less bits, ranging from 0.3 to 1.0
#endif
    int             tc_offset_div2; // offset of LoopFilterTcOffsetDiv2, ranging from -6 to 6
    int             beta_offset_div2; // offset of LoopFilterTcOffsetDiv2, ranging from -6 to 6

    unsigned int    num_ref_pics; // number of ref_frames reserved for cur_frame and future frames
    unsigned int    num_ref_pics_active; // number of ref_frames is permited to be used in L0 or L1

    int             reference_pics[MAX_FRM_NUM-1]; // = ref_frame_poc - cur_frame_poc
    // = discard_frame_poc - cur_frame_poc, means derlta_poc of ref_frames which are discarded
    int             discard_pics[MAX_FRM_NUM-1];

    unsigned char   lt_ref_flag; // 1: enable cur_frame use long term ref_frame
    int             lt_ref_poc; // poc of lt_ref_frame of cur_frame

    // 0 means next 4 member parameters are ignored; 1 means next 3 member parameters are need
    // this parameter of the first frame of a GOP must be 0
    unsigned char   predict;

    unsigned int    delta_rps_idx; // = cur_frame_encoding_idx - predictor_frame_encoding_idx

    int             delta_rps; // = predictor_frame_poc - cur_frame_poc

    // num of ref_idcs to encoder for the current frame, the value is equal to
    // the value of num_st_ref_pics of the predictor_frame + 1 + lt_ref_flag
    unsigned int    num_ref_idcs;

    // [][0]=(ref_frame_poc or discard_frame_poc) - cur_frame_poc
    // [][1]indicating the ref_pictures reserved in ref_list_buffer:
    // [][1]=0: will not be a ref_picture anymore
    // [][1]=1: is a ref_picture used by cur_picture
    // [][1]=2: is a ref_picture used by future_picture
    // [][1]=3: is a long term ref_picture
    int             reference_idcs[MAX_FRM_NUM][2];
}RefPicSet;
typedef struct {
    int gop_size;
    int intra_period;
    int max_num_ref_pics;
    unsigned char num_ref_idx_l0_default_active;
    unsigned char num_ref_idx_l1_default_active;
    RefPicSet ref_str[MAX_GOP_SIZE + 2]; // just when custom_rps_flag is 1, it should be set
    unsigned char use_sps_rps_flag; // if it is 1, rps will not occur in slice_header
    unsigned char use_lt_ref_flag;
    unsigned char custom_rps_flag; // 0: default ref_str will be use; 1: user should set ref_str[]
}VencH265GopStruct;

#define MAX_NUM_MB (65536)
typedef struct {
    unsigned char mb_mad;
    unsigned char mb_qp;
    unsigned int mb_sse;
    double mb_psnr;
}VencMBInfoPara;

typedef struct {
    unsigned int num_mb;
    VencMBInfoPara *p_para;
}VencMBInfo;

typedef struct {
    unsigned char mb_qp; // {5:0}
    unsigned char mb_skip_flag; // {6}
    unsigned char mb_en; // {7}
}VencMBModeCtrlInfo;

typedef struct {
    unsigned char hp_filter_en;
    unsigned int hp_coef_shift; //* range[0 ~ 7],  default: 3
    unsigned int hp_coef_th;    //* range[0 ~ 7],  default: 5
    unsigned int hp_contrast_th;//* range[0 ~ 63], default: 0
    unsigned int hp_mad_th;     //* range[0 ~ 63], default: 0
}VencHighPassFilter;

typedef struct {
    unsigned char hvs_en;
    unsigned int  th_dir;
    unsigned int  th_coef_shift;
}VencHVS;

typedef struct {
    unsigned int inter_tend;
    unsigned int skip_tend;
    unsigned int merge_tend;
}VencH265TendRatioCoef;

typedef struct {
	unsigned char iDenoiseEn; // use qpmap
	unsigned char iDenoiseAdaptEn;
	unsigned char realTimeBrAdaptEn;
	unsigned char motionRAdaptEn;
	unsigned int  uIDenoiseLevel; // range[0~2], default 1
	unsigned int  uBrWeight;      // range[0~256], default 128
	unsigned int  uMotionWeight;  // range[0~256], default 128
	int           iDeltaMinQp;    // range[-3~5], default 0
	int           iDeltaMaxQp;    // range[0~5], default 5
	unsigned char iQpMapOpenEn;
} sVencSmartQpParam;

typedef struct {
    unsigned char smart_fun_en;
    unsigned char img_bin_en;
    unsigned int img_bin_th;
    unsigned int shift_bits;
}VencSmartFun;

typedef struct {
    unsigned int chroma_sample_top;
    unsigned int chroma_sample_bottom;
}VencVUIChromaLoc;

typedef struct {
    unsigned int win_left_offset;
    unsigned int win_right_offset;
    unsigned int win_top_offset;
    unsigned int win_bottom_offset;
}VencVUIDisplayWindow;

typedef struct {
	unsigned char tiles_fixed_structure_flag;
	unsigned char mv_over_pic_boundaries_flag;
	unsigned char restricted_ref_pic_lists_flag;
	unsigned int  min_spatial_seg_idc;
	unsigned int  max_bytes_per_pic_denom;
	unsigned int  max_bits_per_min_cu_denom;
	unsigned int  log2_max_mv_len_hor;
	unsigned int  log2_max_mv_len_ver;
}VencVUIH265BitstreamRestriction;

typedef struct {
	unsigned char mv_over_pic_boundaries_flag;
	unsigned char max_bytes_per_pic_denom;
	unsigned int  max_bits_per_mb_denom;
	unsigned int  log2_max_mv_len_hor;
	unsigned int  log2_max_mv_len_ver;
	unsigned int  max_num_reorder_frames;
	unsigned int  max_dec_frame_buffing;
}VencVUIH264BitstreamRestriction;

typedef struct {
	unsigned char reserve_zero : 2;
	unsigned char constraint_5 : 1;
	unsigned char constraint_4 : 1;
	unsigned char constraint_3 : 1;
	unsigned char constraint_2 : 1;
	unsigned char constraint_1 : 1;
	unsigned char constraint_0 : 1;
} VencH264ConstraintFlag;

typedef struct {
	unsigned int en_force_conf;
	unsigned int left_offset;
	unsigned int right_offset;
	unsigned int top_offset;
	unsigned int bottom_offset;
} VencForceConfWin;

#define SEI_EXTRA_LENGTH (32)

typedef struct {
	unsigned char *pBuffer;
	unsigned int  nBufLen;
	unsigned int  nDataLen;
	unsigned int  nType;
} VencSeiData;

typedef struct {
	unsigned int nSeiNum;
	VencSeiData  *pSeiData;
} VencSeiParam;

typedef enum {
	BUF_IDLE,
	BUF_STANDBY,
	BUF_OCCUPY,
} VENC_BUF_STATUS;

typedef struct {
	int fd;
	unsigned char* pAddrPhyY;
	unsigned char* pAddrPhyC0;
	unsigned char* pAddrPhyC1;
	unsigned char* pAddrVirY;
	unsigned char* pAddrVirC;
	unsigned int nWidth;
	unsigned int nHeight;
	int colorFormat;
} VencIspBufferInfo;

typedef struct {
    unsigned int bScaleFlag;
    unsigned int nRotateAngle;//* 0: no rotate; 1: 90; 2: 180; 3: 270;
    unsigned int bHorizonflipFlag;

    unsigned int bOverlayerFlag;
    VencOverlayInfoS *pOverlayerInfo;

    unsigned int bCropFlag;
    unsigned int bVirZoom;
    VencRect *pCropInfo;

    unsigned int bGdcFlag;
    unsigned int bGdcInfoChange;
    sInputPara *pGdcInfo;

    //* yuv2yuv, 0: disable; 1: BT601 to YCC; 2: YCC to BT601;
    //*                      3: BT709 to YCC; 4: YCC to BT709;
    unsigned int nColorSpaceYuv2Yuv;
    //* rgb2yuv, 0: BT601, 1: BT709, 2: YCC
    unsigned int nColorSpaceRgb2Yuv;
} VencIspFunction;

typedef void* VideoEncoderIsp;

VideoEncoderIsp* VideoEncIspCreate();
void VideoEncIspDestroy(VideoEncoderIsp* pEncIsp);
int VideoEncIspFunction(VideoEncoderIsp* pEncIsp,
                        VencIspBufferInfo* pInBuffer,
                        VencIspBufferInfo* pOutBuffer,
                        VencIspFunction* pIspFunction);

typedef struct aw_crop_data {
    struct ScMemOpsS* pCropMemOps;
    VideoEncoderIsp*  pCropIsp;
    VeOpsS*           pCropVeOpsS;
    void*             pCropVeOpsSelf;
} aw_crop_data_t;

int AWCropInit(aw_crop_data_t* crop_data);

int AWCropYuv(aw_crop_data_t*    crop_data,
              VencIspBufferInfo* pInBuffer,
              VencRect*          pCropInfo,
              VencIspBufferInfo* pOutBuffer,
              int                nIsAlign);

int AWCropYuvAndRotate(aw_crop_data_t*    crop_data,
                       VencIspBufferInfo* pInBuffer,
                       VencRect*          pCropInfo,
                       VencIspBufferInfo* pOutBuffer,
                       int                nIsAlign,
                       int                rot_value);

void AWCropExit(aw_crop_data_t* crop_data);

int AWJpecEnc(JpegEncInfo* pJpegInfo, EXIFInfo* pExifInfo,
    void* pOutBuffer, int* pOutBufferSize);

typedef void* VideoEncoder;

VideoEncoder* VideoEncCreate(VENC_CODEC_TYPE eCodecType);
void VideoEncDestroy(VideoEncoder* pEncoder);
int VideoEncInit(VideoEncoder* pEncoder, VencBaseConfig* pConfig);
int VideoEncUnInit(VideoEncoder* pEncoder);

int AllocInputBuffer(VideoEncoder* pEncoder, VencAllocateBufferParam *pBufferParam);
int GetOneAllocInputBuffer(VideoEncoder* pEncoder, VencInputBuffer* pInputbuffer);
int FlushCacheAllocInputBuffer(VideoEncoder* pEncoder,  VencInputBuffer *pInputbuffer);
int ReturnOneAllocInputBuffer(VideoEncoder* pEncoder,  VencInputBuffer *pInputbuffer);
int ReleaseAllocInputBuffer(VideoEncoder* pEncoder);

int AddOneInputBuffer(VideoEncoder* pEncoder, VencInputBuffer* pInputbuffer);
int VideoEncodeOneFrame(VideoEncoder* pEncoder);
int AlreadyUsedInputBuffer(VideoEncoder* pEncoder, VencInputBuffer* pBuffer);

int ValidBitstreamFrameNum(VideoEncoder* pEncoder);
int GetOneBitstreamFrame(VideoEncoder* pEncoder, VencOutputBuffer* pBuffer);
int FreeOneBitStreamFrame(VideoEncoder* pEncoder, VencOutputBuffer* pBuffer);

int VideoEncGetParameter(VideoEncoder* pEncoder, VENC_INDEXTYPE indexType, void* paramData);
int VideoEncSetParameter(VideoEncoder* pEncoder, VENC_INDEXTYPE indexType, void* paramData);

int VideoEncoderReset(VideoEncoder* pEncoder);
unsigned int VideoEncoderGetUnencodedBufferNum(VideoEncoder* pEncoder);

void VideoEncoderGetVeIommuAddr(VideoEncoder* pEncoder, struct user_iommu_param *pIommuBuf);
void VideoEncoderFreeVeIommuAddr(VideoEncoder* pEncoder, struct user_iommu_param *pIommuBuf);

int VideoEncoderSetFreq(VideoEncoder* pEncoder, int nVeFreq);
void VideoEncoderSetDdrMode(VideoEncoder* pEncoder, int nDdrType);

unsigned int GetIspPhyAddrByFd(VideoEncoderIsp* pIsp, int fd);
void FreeIspPhyAddrByFd(VideoEncoderIsp* pIsp, int fd);

#endif    //_VENCODER_H_

#ifdef __cplusplus
}
#endif /* __cplusplus */
